abstract class Character extends GameEntity {
    protected int health;
    protected int experience;
    protected int defense;

    public Character(String name, int health, int experience, int defense) {
        super(name);
        this.health = health;
        this.experience = experience;
        this.defense = defense;
    }
}