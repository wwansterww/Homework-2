class Monster extends Character {
    public Monster(String name, int health, int experience, int defense) {
        super(name, health, experience, defense);
    }
}