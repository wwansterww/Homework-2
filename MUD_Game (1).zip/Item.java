class Item extends GameEntity {
    public Item(String name) {
        super(name);
    }
}
