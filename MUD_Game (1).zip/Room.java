import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Room extends GameEntity {
    private String description;
    private Map<String, Room> exits;
    private List<Item> items;

    public Room(String name, String description) {
        super(name);
        this.description = description;
        this.exits = new HashMap<>();
        this.items = new ArrayList<>();
    }

    public void setExit(String direction, Room room) {
        exits.put(direction, room);
    }

    public Room getExit(String direction) {
        return exits.get(direction);
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public Item removeItem(String itemName) {
        for (Item item : items) {
            if (item.getName().equalsIgnoreCase(itemName)) {
                items.remove(item);
                return item;
            }
        }
        return null;
    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append("Room: ").append(name).append("\n");
        sb.append(description).append("\n");
        sb.append("Items here: ");
        if (items.isEmpty()) {
            sb.append("None");
        } else {
            for (Item item : items) {
                sb.append(item.getName()).append(", ");
            }
        }
        return sb.toString();
    }
}