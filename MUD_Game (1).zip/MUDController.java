import java.util.Scanner;

public class MUDController {
    private Player player;
    private boolean running;
    private Monster monster;

    public MUDController(Player player) {
        this.player = player;
        this.running = true;
        this.monster = new Monster("Monster", 50, 2, 0);
    }

    public void runGameLoop() {
        Scanner scanner = new Scanner(System.in);
        while (running) {
            System.out.print("> ");
            String input = scanner.nextLine().trim().toLowerCase();
            handleInput(input);
        }
        scanner.close();
    }

    private void handleInput(String input) {
        String[] parts = input.split(" ", 2);
        String command = parts[0];
        String argument = parts.length > 1 ? parts[1] : "";

        switch (command) {
            case "look":
                System.out.println(player.getCurrentRoom().describe());
                break;
            case "move":
                move(argument);
                break;
            case "pick":
                if (argument.startsWith("up ")) {
                    pickUp(argument.substring(3));
                } else {
                    System.out.println("Invalid command.");
                }
                break;
            case "inventory":
                player.showInventory();
                break;
            case "fight":
                fightMonster();
                break;
            case "help":
                showHelp();
                break;
            case "quit":
            case "exit":
                running = false;
                System.out.println("Goodbye!");
                break;
            default:
                System.out.println("Unknown command.");
        }
    }

    private void move(String direction) {
        Room nextRoom = player.getCurrentRoom().getExit(direction);
        if (nextRoom != null) {
            player.move(nextRoom);
            System.out.println("You moved " + direction);
            System.out.println(player.getCurrentRoom().describe());
        } else {
            System.out.println("You can't go that way!");
        }
    }

    private void pickUp(String itemName) {
        Item item = player.getCurrentRoom().removeItem(itemName);
        if (item != null) {
            player.addItem(item);
            System.out.println("You picked up " + item.getName());
        } else {
            System.out.println("No item named " + itemName + " here!");
        }
    }

    private void fightMonster() {
        System.out.println("You fight the monster!");
        player.health -= 50;
        player.experience += monster.experience;
        System.out.println("You defeated the monster! Lost 50 HP, gained " + monster.experience + " XP.");
    }

    private void showHelp() {
        System.out.println("Available commands:");
        System.out.println("look - Describe the current room");
        System.out.println("move <direction> - Move in a specified direction");
        System.out.println("pick up <item> - Pick up an item");
        System.out.println("fight - Fight the monster");
        System.out.println("inventory - Show your inventory");
        System.out.println("help - Show available commands");
        System.out.println("quit/exit - End the game");
    }
    public static void main(String[] args) {
        Room startRoom = new Room("Start Room", "A small dark room with a key on the floor.");
        startRoom.addItem(new Item("Key"));

        Room weaponRoom = new Room("Weapon Room", "A room with three weapons: sword, staff, and bow. Pick one.");
        weaponRoom.addItem(new Item("sword"));
        weaponRoom.addItem(new Item("staff"));
        weaponRoom.addItem(new Item("bow"));

        Room monsterRoom = new Room("Monster Room", "A room with a dangerous monster.");
        Room potionRoom = new Room("Potion Room", "A room with healing potions.");
        Room ratRoom = new Room("Rat Room", "A room full of aggressive rats.");
        Room library = new Room("Library", "An ancient library with useful knowledge.");
        Room finalRoom = new Room("Final Room", "An entrance to the second floor.");

        startRoom.setExit("north", weaponRoom);
        weaponRoom.setExit("west", monsterRoom);
        weaponRoom.setExit("east", potionRoom);
        weaponRoom.setExit("north", ratRoom);
        monsterRoom.setExit("east", weaponRoom);
        potionRoom.setExit("west", weaponRoom);
        ratRoom.setExit("north", library);
        library.setExit("east", finalRoom);

        Player player = new Player(startRoom);
        MUDController controller = new MUDController(player);
        controller.runGameLoop();
    }

}
